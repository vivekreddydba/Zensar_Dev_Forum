package com.zensar.df.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.df.dto.UserDto;
import com.zensar.df.utils.JwtUtils;
import com.zensar.df.dto.UserDto;

@RestController
@CrossOrigin(origins="*")
@RequestMapping(value = "/devforum")
@ResponseBody
public class UserController {
	
	//login
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JwtUtils jwtUtils;
	
	@PostMapping(value="/user/authenticate", consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> authenticate(@RequestBody UserDto authRequest){
		System.out.println(authRequest);
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authRequest.getUsername(),authRequest.getPassword())
					);
		}
		catch(BadCredentialsException e) {
			throw new BadCredentialsException(authRequest.getUsername());
		}
		String jwtToken = jwtUtils.generateToken(authRequest.getUsername());
		return new ResponseEntity<String>(jwtToken,HttpStatus.OK);
		
	}
	//login
	
	@PostMapping(value = "/user/authenticate", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> authenticateUser(@RequestBody User login){
		login.setName("Bharath");
		return new ResponseEntity("348",HttpStatus.OK);
		
	}
	
	
	@PostMapping(value = "/user", consumes= {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<UserDto> registerUser(@RequestBody UserDto userdto) {
		lastUserId = lastUserId+1;
		userdto.setId(lastUserId);
		users.add(userdto);
		return new ResponseEntity(userdto,HttpStatus.OK);
		
		
	}
	
	@GetMapping("/all")
	public String viewAll() {
		return "hello All";
	}
	@GetMapping("/user")
	public String viewUser() {
		return "Hello User";
	}
	@GetMapping("/admin")
	public String viewAdmi() {
		return "Hello Admin";
	}
				
	
	static List<UserDto> users = new ArrayList<>();
	static int lastUserId = 0;

}
