package com.zensar.df;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DfUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(DfUserManagementApplication.class, args);
	}

}
